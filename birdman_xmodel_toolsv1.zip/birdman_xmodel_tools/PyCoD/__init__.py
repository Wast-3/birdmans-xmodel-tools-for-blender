# <pep8 compliant>

from .xmodel import Model
from .xanim import Anim
from .sanim import SiegeAnim

version = (0, 3, 0)  # Version specifier for PyCoD
